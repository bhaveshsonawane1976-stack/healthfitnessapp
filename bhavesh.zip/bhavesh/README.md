# Health Tracker Diet Planner

## What this app does
- Tracks diet planner items for hair, skin, and fitness.
- Lets you add any new food item with calories, protein, carbs, fat, and category.
- Stores items in a Spring Boot backend using an H2 in-memory database.
- Shows a simple nutrition summary and list of added diet items.

## How to run
1. Open a terminal in `c:\Users\nikhi\Desktop\bhavesh`
2. Run the backend:
   - `mvn spring-boot:run`
3. Open the frontend in your browser:
   - `c:\Users\nikhi\Desktop\bhavesh\frontend\index.html`
4. Use the form to add a new diet item. Each submission saves it and updates the list.

## Backend API
- `GET /api/diets` - fetch all diet items
- `POST /api/diets` - add a new diet item
- `GET /api/daily-logs` - fetch daily health logs
- `POST /api/daily-logs` - save a daily health log
- `GET /api/reminders` - fetch reminders
- `POST /api/reminders` - create a reminder
- `GET /api/progress` - get progress scores and hair fall prediction

## Example diet request body
```json
{
  "name": "Almonds",
  "category": "Hair-Friendly",
  "calories": 160,
  "protein": 6,
  "carbs": 6,
  "fat": 14
}
```

## Example daily log request body
```json
{
  "date": "2026-06-13",
  "water": 3000,
  "protein": 80,
  "sleepHours": 7.5,
  "steps": 9000,
  "weight": 72.5,
  "hairFallCount": 20,
  "oilApplied": true,
  "washDone": true,
  "minoxidilTaken": true,
  "tabletTaken": true,
  "stressLevel": 4,
  "acneCount": 2,
  "facewashDone": true,
  "sunscreenDone": true
}
```

## Example reminder request body
```json
{
  "type": "Minoxidil",
  "message": "Take minoxidil now",
  "time": "20:30",
  "active": true
}
```

## Prompt for the app
If you want to tell me what to build next, use this prompt:

> Build a health tracker app with diet items, daily logs, reminders, hair prediction, and progress scoring.

## Next step
To add more features, I can help you add daily logs for water, sleep, and hair fall next.
