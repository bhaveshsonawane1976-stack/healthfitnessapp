package com.example.healthtracker.controller;

import com.example.healthtracker.model.DietItem;
import com.example.healthtracker.repository.DietItemRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/api/diets")
public class DietController {

    private final DietItemRepository dietItemRepository;

    public DietController(DietItemRepository dietItemRepository) {
        this.dietItemRepository = dietItemRepository;
    }

    @GetMapping
    public List<DietItem> getAllDietItems() {
        return dietItemRepository.findAll();
    }

    @PostMapping
    public DietItem addDietItem(@RequestBody DietItem dietItem) {
        Objects.requireNonNull(dietItem, "dietItem must not be null");
        return dietItemRepository.save(dietItem);
    }
}
