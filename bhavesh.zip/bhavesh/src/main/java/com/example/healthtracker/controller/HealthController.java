package com.example.healthtracker.controller;

import com.example.healthtracker.model.DailyLog;
import com.example.healthtracker.model.Reminder;
import com.example.healthtracker.repository.DailyLogRepository;
import com.example.healthtracker.repository.ReminderRepository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class HealthController {

    private final DailyLogRepository dailyLogRepository;
    private final ReminderRepository reminderRepository;

    public HealthController(DailyLogRepository dailyLogRepository, ReminderRepository reminderRepository) {
        this.dailyLogRepository = dailyLogRepository;
        this.reminderRepository = reminderRepository;
    }

    @GetMapping("/daily-logs")
    public List<DailyLog> getDailyLogs() {
        return dailyLogRepository.findAll();
    }

    @PostMapping("/daily-logs")
    public DailyLog saveDailyLog(@RequestBody DailyLog dailyLog) {
        if (dailyLog.getDate() == null) {
            dailyLog.setDate(LocalDate.now());
        }
        return dailyLogRepository.save(dailyLog);
    }

    @GetMapping("/reminders")
    public List<Reminder> getReminders() {
        return reminderRepository.findAll();
    }

    @PostMapping("/reminders")
    public Reminder addReminder(@RequestBody Reminder reminder) {
        if (reminder.getActive() == null) {
            reminder.setActive(true);
        }
        return reminderRepository.save(reminder);
    }

    @GetMapping("/progress")
    public Map<String, Object> getProgress() {
        List<DailyLog> logs = dailyLogRepository.findAll();
        int count = logs.size();
        double totalHairScore = 0;
        double totalSkinScore = 0;
        double totalGoalScore = 0;
        int totalWater = 0;
        int totalProtein = 0;
        double totalSleep = 0;
        int tracked = 0;

        for (DailyLog log : logs) {
            int hairScore = 0;
            if (log.getSleepHours() != null && log.getSleepHours() >= 7) hairScore += 20;
            if (log.getProtein() != null && log.getProtein() >= 60) hairScore += 20;
            if (log.getWater() != null && log.getWater() >= 3000) hairScore += 20;
            if (Boolean.TRUE.equals(log.getOilApplied())) hairScore += 20;
            if (Boolean.TRUE.equals(log.getMinoxidilTaken())) hairScore += 20;

            int skinScore = 0;
            if (log.getSleepHours() != null && log.getSleepHours() >= 7) skinScore += 20;
            if (Boolean.TRUE.equals(log.getFacewashDone())) skinScore += 20;
            if (Boolean.TRUE.equals(log.getSunscreenDone())) skinScore += 20;
            if (log.getWater() != null && log.getWater() >= 3000) skinScore += 20;
            if (log.getProtein() != null && log.getProtein() >= 50) skinScore += 20;

            int goalScore = 0;
            if (log.getSteps() != null && log.getSteps() >= 8000) goalScore += 20;
            if (log.getWeight() != null) goalScore += 20;
            if (log.getSleepHours() != null && log.getSleepHours() >= 7) goalScore += 20;
            if (log.getProtein() != null && log.getProtein() >= 50) goalScore += 20;
            if (log.getWater() != null && log.getWater() >= 3000) goalScore += 20;

            totalHairScore += hairScore;
            totalSkinScore += skinScore;
            totalGoalScore += goalScore;
            if (log.getWater() != null) totalWater += log.getWater();
            if (log.getProtein() != null) totalProtein += log.getProtein();
            if (log.getSleepHours() != null) totalSleep += log.getSleepHours();
            tracked++;
        }

        Map<String, Object> result = new HashMap<>();
        result.put("daysTracked", count);
        result.put("averageHairScore", tracked > 0 ? Math.round(totalHairScore / tracked) : 0);
        result.put("averageSkinScore", tracked > 0 ? Math.round(totalSkinScore / tracked) : 0);
        result.put("averageGoalScore", tracked > 0 ? Math.round(totalGoalScore / tracked) : 0);
        result.put("averageWater", tracked > 0 ? Math.round((double) totalWater / tracked) : 0);
        result.put("averageProtein", tracked > 0 ? Math.round((double) totalProtein / tracked) : 0);
        result.put("averageSleep", tracked > 0 ? Math.round(totalSleep / tracked * 10) / 10.0 : 0);
        result.put("prediction", predictHairFall(logs));
        return result;
    }

    private Map<String, Object> predictHairFall(List<DailyLog> logs) {
        Map<String, Object> prediction = new HashMap<>();
        if (logs.isEmpty()) {
            prediction.put("message", "Add daily logs before prediction.");
            prediction.put("expectedHairFall", 0);
            return prediction;
        }

        double weightSum = 0;
        double targetSum = 0;
        for (DailyLog log : logs) {
            if (log.getWater() != null && log.getProtein() != null && log.getSleepHours() != null && log.getHairFallCount() != null) {
                weightSum += log.getWater() / 1000.0 + log.getProtein() / 50.0 + (log.getSleepHours() / 7.0);
                targetSum += log.getHairFallCount();
            }
        }

        if (weightSum == 0) {
            prediction.put("message", "Not enough data for prediction.");
            prediction.put("expectedHairFall", 0);
            return prediction;
        }

        double avgHairFall = targetSum / logs.size();
        double score = weightSum / logs.size();
        double expectedHairFall = Math.max(0, Math.round((avgHairFall - score * 2) * 10) / 10.0);

        prediction.put("message", "Estimated trend based on water, protein, and sleep.");
        prediction.put("expectedHairFall", expectedHairFall);
        return prediction;
    }
}
