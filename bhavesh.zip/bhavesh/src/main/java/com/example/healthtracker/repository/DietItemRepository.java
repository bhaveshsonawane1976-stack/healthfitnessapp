package com.example.healthtracker.repository;

import com.example.healthtracker.model.DietItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DietItemRepository extends JpaRepository<DietItem, Long> {
}
