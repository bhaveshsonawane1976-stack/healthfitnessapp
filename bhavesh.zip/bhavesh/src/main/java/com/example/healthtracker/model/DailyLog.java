package com.example.healthtracker.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "daily_logs")
public class DailyLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate date;
    private Integer water;
    private Integer protein;
    private Double sleepHours;
    private Integer steps;
    private Double weight;
    private Integer hairFallCount;
    private Boolean oilApplied;
    private Boolean washDone;
    private Boolean minoxidilTaken;
    private Boolean tabletTaken;
    private Integer acneCount;
    private Boolean facewashDone;
    private Boolean sunscreenDone;
    private Integer stressLevel;

    public DailyLog() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Integer getWater() {
        return water;
    }

    public void setWater(Integer water) {
        this.water = water;
    }

    public Integer getProtein() {
        return protein;
    }

    public void setProtein(Integer protein) {
        this.protein = protein;
    }

    public Double getSleepHours() {
        return sleepHours;
    }

    public void setSleepHours(Double sleepHours) {
        this.sleepHours = sleepHours;
    }

    public Integer getSteps() {
        return steps;
    }

    public void setSteps(Integer steps) {
        this.steps = steps;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Integer getHairFallCount() {
        return hairFallCount;
    }

    public void setHairFallCount(Integer hairFallCount) {
        this.hairFallCount = hairFallCount;
    }

    public Boolean getOilApplied() {
        return oilApplied;
    }

    public void setOilApplied(Boolean oilApplied) {
        this.oilApplied = oilApplied;
    }

    public Boolean getWashDone() {
        return washDone;
    }

    public void setWashDone(Boolean washDone) {
        this.washDone = washDone;
    }

    public Boolean getMinoxidilTaken() {
        return minoxidilTaken;
    }

    public void setMinoxidilTaken(Boolean minoxidilTaken) {
        this.minoxidilTaken = minoxidilTaken;
    }

    public Boolean getTabletTaken() {
        return tabletTaken;
    }

    public void setTabletTaken(Boolean tabletTaken) {
        this.tabletTaken = tabletTaken;
    }

    public Integer getAcneCount() {
        return acneCount;
    }

    public void setAcneCount(Integer acneCount) {
        this.acneCount = acneCount;
    }

    public Boolean getFacewashDone() {
        return facewashDone;
    }

    public void setFacewashDone(Boolean facewashDone) {
        this.facewashDone = facewashDone;
    }

    public Boolean getSunscreenDone() {
        return sunscreenDone;
    }

    public void setSunscreenDone(Boolean sunscreenDone) {
        this.sunscreenDone = sunscreenDone;
    }

    public Integer getStressLevel() {
        return stressLevel;
    }

    public void setStressLevel(Integer stressLevel) {
        this.stressLevel = stressLevel;
    }
}
